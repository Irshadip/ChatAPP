//
//  ST_ChatApp.swift
//  ST_Chat
//
//  Created by Siddhesh on 14/02/24.
//

import SwiftUI

@main
struct ST_ChatApp: App {
    var body: some Scene {
        WindowGroup {
//            LoginView(didCompleteLoginProcess: {
//
//            })
            MainMessagesView()
//            CreateNewMessageView()
        }
    }
}
